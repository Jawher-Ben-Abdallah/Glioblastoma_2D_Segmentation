# PFE2020
Glioblastoma Segmentation

The goal of this project is to create a computationally inexpensive pipeline for glioblastoma brain tumor segmentation.
In this Notebook, we will detail the different approaches taken to reduce the computational overhead often encountered when working with 3D medical data.
